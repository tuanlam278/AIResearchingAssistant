import asyncio
import logging
from typing import Dict, List

import fitz  # PyMuPDF
from PIL import Image
from google import genai
from google.genai import types

# Nhập "trái tim" cấu hình của project
from app.config import settings

logger = logging.getLogger(__name__)

# Khởi tạo Client bằng key lấy thẳng từ settings (Pydantic đã lo vụ đọc .env)
client = genai.Client(api_key=settings.GOOGLE_API_KEY)

def _convert_pdf_to_images(file_bytes: bytes) -> List:
    """
    Chuyển PDF sang ảnh bằng PyMuPDF (không cần poppler, deploy cực nhàn)
    """
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    images = []
    
    for page in doc:
        # Chuyển trang thành ảnh với độ phân giải khoảng 150-200 DPI
        pix = page.get_pixmap(matrix=fitz.Matrix(2, 2)) 
        
        # Convert sang định dạng PIL Image để feed vào Gemini
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        images.append(img)
        
    return images

async def _extract_text_from_image(image, page_num: int) -> str:
    prompt = """
    Hãy đóng vai một chuyên gia bóc tách dữ liệu. Nhiệm vụ của bạn là trích xuất toàn bộ nội dung trong bức ảnh (trang tài liệu) này sang định dạng Markdown.
    
    Yêu cầu bắt buộc:
    1. Giữ nguyên cấu trúc các cột, đoạn văn.
    2. Biểu diễn bảng biểu bằng Markdown table (| Header | Header |).
    3. Trích xuất chính xác các công thức toán học, ký hiệu đặc biệt.
    4. Không bỏ sót bất kỳ chữ nào, không bịa thêm nội dung.
    5. Chỉ trả về nội dung Markdown, không thêm lời chào hay giải thích gì thêm.
    """
    try:
        # Gọi Gemini 2.5 Flash thông qua Async Client
        response = await client.aio.models.generate_content(
            model='gemini-2.5-flash',
            contents=[image, prompt],
            config=types.GenerateContentConfig(temperature=0.0)
        )
        return response.text.strip()
    except Exception as e:
        logger.error(f"Lỗi gọi Gemini ở trang {page_num}: {e}")
        return ""

async def parse_pdf(file_bytes: bytes) -> List[Dict]:
    """
    Parse PDF bằng Vision LLM.
    """
    logger.info("Bắt đầu chuyển PDF sang ảnh...")
    try:
        images = await asyncio.to_thread(_convert_pdf_to_images, file_bytes)
    except Exception as e:
        logger.error(f"Lỗi pdf2image: {e}")
        raise ValueError(f"Không thể chuyển PDF sang ảnh. (Kiểm tra cài đặt poppler): {e}") from e

    total_pages = len(images)
    logger.info(f"Đã chuyển thành {total_pages} ảnh. Bắt đầu trích xuất bằng Gemini...")

    pages: List[Dict] = []
    failed_pages: List[int] = []

    for i, img in enumerate(images, start=1):
        logger.info(f"Đang phân tích trang {i}/{total_pages}...")
        content = await _extract_text_from_image(img, i)
        
        if not content:
            failed_pages.append(i)
        else:
            pages.append({"page_number": i, "content": content})
        
        # Delay nhẹ để tránh lỗi 429 Too Many Requests từ Google API (Free Tier)
        if i < total_pages:
            await asyncio.sleep(2)

    non_empty = sum(1 for p in pages if p["content"])
    logger.info(
        f"Parse hoàn tất: {non_empty}/{total_pages} trang có nội dung"
        + (f", {len(failed_pages)} trang lỗi: {failed_pages}." if failed_pages else ".")
    )

    if non_empty == 0:
        raise RuntimeError("PARSE_FAILED: Gemini không trích xuất được nội dung nào.")

    return pages